//package com.android.AttendenceTracker;

import android.app.Activity;


public class KbdInputActivity extends Activity {

}
